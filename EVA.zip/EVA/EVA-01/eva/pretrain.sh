MODEL=mae_vit_base_patch16_dec512d8b
# MODEL=mae_vit_large_patch16_dec512d8b
# MODEL=mae_vit_huge_patch16_dec512d8b
# MODEL=mae_vit_giga_patch16_dec512d8b
# MODEL=mae_vit_e_patch16_dec512d8b
# MODEL=mae_vit_22b_patch16_dec512d8b
# MODEL=mae_vit_huge_patch14_dec512d8b
# MODEL=mae_vit_large_patch14_dec512d4b
DATA_PATH=/home/zq/pycode/EVA2/EVA/EVA-01/eva/merged_30m_pt
VAL_DATA_PATH=/home/zq/pycode/EVA2/EVA/EVA-01/eva/merged_30m_pt/21k/imagenet21k # monitoring val loss 

input_size=224
# num_mask_patches=105 ### 224*224/14/14 * 0.4 ###4
num_mask_patches=80 ### 224*224/14/14 * 0.4 ###

batch_size=64
update_freq=1

lr=1e-3
# lr=1e-5
b2=0.98
eps=1e-6
dpr=0.1
ls=0.0

epochs=150
wmep=2

mixup=0.0
cj=0.0

zero_stage=1
save_ckpt_freq=1

teacher_type=clip
clip_model=ViT-B/16
cache_dir=./cache/clip/large   # "ViT-L/14": "https://openaipublic.azureedge.net/clip/models/b8cca3fd41ae0c99ba7e8951adf17d267cdb84cd88be6f7c2e0eca1737a03836/ViT-L-14.pt",


EXP_NAME=merge30M_${MODEL}_sz${input_size}_mask${num_mask_patches}_lr${lr}_b2${b2}_eps${eps}_dpr${dpr}_ls${ls}_bsz16x8x${batch_size}_ep${epochs}_wmep${wmep}_cj${cj}_ftpye${feature_type}_ltype${loss_type}_mixup${mixup}_abspos

OUTPUT_DIR=./output/${epochs}/${EXP_NAME}

MASTER_ADDR=127.0.0.1

PROTOCOL_BUFFERS_PYTHON_IMPLEMENTATION=python python -m torch.distributed.launch --nproc_per_node=1 \
        --master_addr=$MASTER_ADDR --master_port=12355 --use_env run_eva_pretraining.py \
        --data_path ${DATA_PATH} \
        --val_data_path ${VAL_DATA_PATH} \
        --output_dir ${OUTPUT_DIR} \
        --log_dir ${OUTPUT_DIR}/tb_log \
        --model ${MODEL} \
        --teacher_type ${teacher_type} \
        --clip_model ${clip_model} \
        --cache_dir ${cache_dir} \
        --input_size ${input_size} --second_input_size ${input_size} \
        --num_mask_patches ${num_mask_patches} \
        --layer_scale_init_value ${ls} \
        --batch_size ${batch_size} \
        --lr ${lr} \
        --opt_betas 0.9 ${b2} \
        --opt_eps ${eps} \
        --drop_path ${dpr} \
        --epochs ${epochs} \
        --mixup ${mixup} \
        --color_jitter ${cj} \
        --warmup_epochs ${wmep} \
        --update_freq ${update_freq} \
        --clip_grad 3.0 \
        --weight_decay 0.05 \
        --rand \
        --zero_stage ${zero_stage} \
        --save_ckpt_freq ${save_ckpt_freq} \
        --mae \
        --enable_deepspeed 
        # --auto_resume
        # --auto_resume_iter \
        # --nnodes=$NNODES --node_rank=$NODE_RANK \
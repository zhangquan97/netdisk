detectron2.utils 
========================

detectron2.utils.colormap module
--------------------------------

.. automodule:: detectron2.utils.colormap
    :members:
    :undoc-members:
    :show-inheritance:

detectron2.utils.comm module
----------------------------

.. automodule:: detectron2.utils.comm
    :members:
    :undoc-members:
    :show-inheritance:


detectron2.utils.events module
------------------------------

.. automodule:: detectron2.utils.events
    :members:
    :undoc-members:
    :show-inheritance:


detectron2.utils.logger module
------------------------------

.. automodule:: detectron2.utils.logger
    :members:
    :undoc-members:
    :show-inheritance:


detectron2.utils.registry module
--------------------------------

.. automodule:: detectron2.utils.registry
    :members:
    :undoc-members:
    :show-inheritance:

detectron2.utils.memory module
----------------------------------

.. automodule:: detectron2.utils.memory
    :members:
    :undoc-members:
    :show-inheritance:


detectron2.utils.analysis module
----------------------------------

.. automodule:: detectron2.utils.analysis
    :members:
    :undoc-members:
    :show-inheritance:


detectron2.utils.visualizer module
----------------------------------

.. automodule:: detectron2.utils.visualizer
    :members:
    :undoc-members:
    :show-inheritance:

detectron2.utils.video\_visualizer module
-----------------------------------------

.. automodule:: detectron2.utils.video_visualizer
    :members:
    :undoc-members:
    :show-inheritance:

